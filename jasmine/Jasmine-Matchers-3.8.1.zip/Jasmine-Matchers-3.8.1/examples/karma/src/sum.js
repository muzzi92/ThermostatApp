window.sum = function (a, b) {
  return a + b;
};
