## Installation

##### npm

```
npm install jasmine-expect --save-dev
```

##### Bower

```
bower install jasmine-expect --save-dev
```

##### Manual

Downloads are available on the [releases](https://github.com/JamieMason/Jasmine-Matchers/releases) page.
