const memberMatcherFor = require('./lib/memberMatcherFor');
const toBeArrayOfNumbers = require('./toBeArrayOfNumbers');

module.exports = memberMatcherFor(toBeArrayOfNumbers);
