const memberMatcherFor = require('./lib/memberMatcherFor');
const toBeBoolean = require('./toBeBoolean');

module.exports = memberMatcherFor(toBeBoolean);
