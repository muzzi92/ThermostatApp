const memberMatcherFor = require('./lib/memberMatcherFor');
const toBeDate = require('./toBeDate');

module.exports = memberMatcherFor(toBeDate);
