module.exports = actual => actual instanceof RegExp;
