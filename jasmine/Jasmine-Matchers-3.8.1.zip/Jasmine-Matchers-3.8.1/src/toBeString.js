const is = require('./lib/is');

module.exports = is.String;
