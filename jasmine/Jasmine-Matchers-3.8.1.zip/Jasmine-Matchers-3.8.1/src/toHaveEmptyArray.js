const memberMatcherFor = require('./lib/memberMatcherFor');
const toBeEmptyArray = require('./toBeEmptyArray');

module.exports = memberMatcherFor(toBeEmptyArray);
