const toBeArrayOfSize = require('./toBeArrayOfSize');

module.exports = actual => toBeArrayOfSize(0, actual);
