module.exports = actual => actual === '';
