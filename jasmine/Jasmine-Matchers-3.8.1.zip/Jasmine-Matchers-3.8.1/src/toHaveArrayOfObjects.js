const memberMatcherFor = require('./lib/memberMatcherFor');
const toBeArrayOfObjects = require('./toBeArrayOfObjects');

module.exports = memberMatcherFor(toBeArrayOfObjects);
