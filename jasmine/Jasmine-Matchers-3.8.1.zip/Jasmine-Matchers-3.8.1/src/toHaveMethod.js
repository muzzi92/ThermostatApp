const memberMatcherFor = require('./lib/memberMatcherFor');
const toBeFunction = require('./toBeFunction');

module.exports = memberMatcherFor(toBeFunction);
