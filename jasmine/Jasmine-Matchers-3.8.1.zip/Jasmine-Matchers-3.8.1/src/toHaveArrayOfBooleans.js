const memberMatcherFor = require('./lib/memberMatcherFor');
const toBeArrayOfBooleans = require('./toBeArrayOfBooleans');

module.exports = memberMatcherFor(toBeArrayOfBooleans);
