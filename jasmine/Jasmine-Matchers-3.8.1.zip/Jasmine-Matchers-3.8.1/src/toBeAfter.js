const toBeBefore = require('./toBeBefore');

module.exports = (otherDate, actual) => toBeBefore(actual, otherDate);
