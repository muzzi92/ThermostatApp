const memberMatcherFor = require('./lib/memberMatcherFor');
const toBeArray = require('./toBeArray');

module.exports = memberMatcherFor(toBeArray);
