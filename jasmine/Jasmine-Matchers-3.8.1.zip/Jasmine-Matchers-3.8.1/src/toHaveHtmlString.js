const memberMatcherFor = require('./lib/memberMatcherFor');
const toBeHtmlString = require('./toBeHtmlString');

module.exports = memberMatcherFor(toBeHtmlString);
