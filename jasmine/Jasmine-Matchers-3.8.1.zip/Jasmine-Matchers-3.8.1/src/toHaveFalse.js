const memberMatcherFor = require('./lib/memberMatcherFor');
const toBeFalse = require('./toBeFalse');

module.exports = memberMatcherFor(toBeFalse);
