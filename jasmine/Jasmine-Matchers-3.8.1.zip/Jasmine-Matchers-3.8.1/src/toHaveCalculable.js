const memberMatcherFor = require('./lib/memberMatcherFor');
const toBeCalculable = require('./toBeCalculable');

module.exports = memberMatcherFor(toBeCalculable);
