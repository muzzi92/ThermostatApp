const describeToHaveX = require('./lib/describeToHaveX');

describe('toHaveMember', () => {
  describeToHaveX('toHaveMember', () => {});
});
